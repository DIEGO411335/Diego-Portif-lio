<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suporte - Loja Retrô 90s</title>
    <style>
        body {
            background-color: #ffcc00;
            font-family: 'Press Start 2P', cursive;
            text-align: center;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background: #ff3366;
            padding: 20px;
            color: white;
            font-size: 24px;
        }
        .container {
            margin-top: 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 80%;
            max-width: 600px;
            margin: 30px auto;
        }
        .form-input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-button {
            background-color: #ff3366;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        .form-button:hover {
            background-color: #e6005c;
        }
        footer {
            margin-top: 30px;
            font-size: 14px;
        }
        .suporte-btn {
            background: #000;
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            font-size: 14px;
            border-radius: 5px;
            font-family: Arial, sans-serif;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <header>Suporte - Loja Retrô 90s</header>
    <div class="container">
        <h2>Fale com nosso Suporte!</h2>
        <p>Se você tiver dúvidas ou precisar de assistência, preencha o formulário abaixo e entraremos em contato o mais rápido possível.</p>

        <!-- Formulário de Suporte -->
        <form action="suporte.php" method="POST">
            <input type="text" name="nome" class="form-input" placeholder="Seu nome" required>
            <input type="email" name="email" class="form-input" placeholder="Seu e-mail" required>
            <textarea name="mensagem" class="form-input" placeholder="Sua mensagem" rows="5" required></textarea>
            <button type="submit" class="form-button">Enviar Mensagem</button>
        </form>
    </div>

    <footer>
        <p>&copy; 2025 Loja Retrô 90s. Todos os direitos reservados.</p>
    </footer>

    <a href="file:///E:/trabalho%20do%20site/projeto.html" class="suporte-btn">Voltar para a Loja</a>
</body>
</html>

<?php
// Verificando se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtendo os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $mensagem = $_POST['mensagem'];

    // Validar se os campos não estão vazios
    if (empty($nome) || empty($email) || empty($mensagem)) {
        echo "Todos os campos são obrigatórios!";
    } else {
        // Aqui você pode salvar ou enviar os dados. Exemplo: enviar um e-mail ou salvar em um banco de dados
        echo "Mensagem enviada com sucesso!"; // Simula o envio
    }
}
?>

